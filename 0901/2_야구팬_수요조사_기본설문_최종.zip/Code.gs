function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('야구팬 수요조사')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function saveData(data) {
  try {
    var SPREADSHEET_URL = "여기에_스프레드시트_링크를_넣으세요"; 
    var sheet = SpreadsheetApp.openByUrl(SPREADSHEET_URL).getActiveSheet();
    sheet.appendRow([
      data.name, 
      data.phone, 
      data.frequency, 
      data.team, 
      data.reasonLike, 
      data.reasonDislike
    ]);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.toString() };
  }
}
